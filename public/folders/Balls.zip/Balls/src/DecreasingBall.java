/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author David
 */
public class DecreasingBall extends Ball 
{
    
    public DecreasingBall(int pX, int pY, int pRadius) 
    {
        super(pX, pY, pRadius);
        setCurrentRadius(pRadius);  
    }
        
    public void changeCurrentRadius()
    {       
        int getB;
        
        getB = getCurrentRadius() - 1;
        
        setCurrentRadius(getB);    
    }
}
