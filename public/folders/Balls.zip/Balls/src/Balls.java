
import java.awt.Graphics;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author David
 */
public class Balls 
{
    private ArrayList<Ball> alBalls = new ArrayList<Ball>();

    public void add(Ball e)
    {
        alBalls.add(e);
    }
    
    public void draw(Graphics g)
    {
        int i;
        
        for(i = 0; i < alBalls.size(); i++)
        {
            alBalls.get(i).draw(g);
        }
    }
    
    public void change()
    {
        int i;
        
        for(i = alBalls.size()-1; i >= 0; i--)
        {
            alBalls.get(i).changeCurrentRadius(); 
            
            if(alBalls.get(i).getCurrentRadius() > alBalls.get(i).getMaximumRadius())
            {
                alBalls.remove(i);
            }
            else
            {
                if(alBalls.get(i).getCurrentRadius() == 0)
                {
                    alBalls.remove(i); 
                }
            }
        }
    }
}
