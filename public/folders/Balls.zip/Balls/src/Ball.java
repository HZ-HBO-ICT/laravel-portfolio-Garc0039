
import java.awt.Color;
import java.awt.Graphics;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author David
 */
public class Ball
{
    private int x;
    private int y;
    private int maximumRadius;
    private int currentRadius;
    private Color color;
    
    public Ball(int pX, int pY, int pRadius)
    {
        x = pX;
        y = pY;
        maximumRadius = pRadius;
        
        int min, max, r, g, b;
        min = 0;
        max = 255;
        r = (int)(Math.random()*(max-min+1))+min;
        g = (int)(Math.random()*(max-min+1))+min;
        b = (int)(Math.random()*(max-min+1))+min;
        color = new Color(r, g, b);
    }
    
    public void draw(Graphics g)
    {
        g.setColor(Color.black);
        g.drawOval(x-currentRadius, y-currentRadius, currentRadius*2, currentRadius*2);
        
        g.setColor(color);
        g.fillOval(x-currentRadius, y-currentRadius, currentRadius*2, currentRadius*2); 
    }

    public void setCurrentRadius(int currentRadius) 
    {
        this.currentRadius = currentRadius;
    }

    public int getCurrentRadius()
    {
        return currentRadius;
    }
    
    public void changeCurrentRadius()
    {
        // Methode vide
    }

    public int getMaximumRadius()
    {
        return maximumRadius;
    }
    
}
