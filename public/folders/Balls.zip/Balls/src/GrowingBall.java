/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author David
 */
public class GrowingBall extends Ball
{
    
    public GrowingBall(int pX, int pY, int pRadius)
    {
        super(pX, pY, pRadius);
        
        int radius = 1;
        setCurrentRadius(radius);
    }
    
    public void changeCurrentRadius()
    {
        int getB;
        
        getB = getCurrentRadius() + 1;
        
        setCurrentRadius(getB);   
    }
}
