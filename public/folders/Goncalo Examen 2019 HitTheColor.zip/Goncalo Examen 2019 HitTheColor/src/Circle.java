
import java.awt.Graphics;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


public class Circle extends Target {

    public Circle(int x, int y, int side, int xStep, int yStep) {
        super(x, y, side, xStep, yStep);
    }
    
    public void draw(Graphics g)
    {
        super.draw(g);
        g.setColor(super.getColor());
        g.fillOval(super.getX()+5, super.getY()+5, (super.getSide()-10), (super.getSide()-10));
        
    }
    
}
