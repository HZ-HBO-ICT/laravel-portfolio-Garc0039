
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author estgo
 */
public class Target 
{
 
    private int x;
    private int y;
    private int side;
    private int xStep;
    private int yStep;
    private Color color;
    private String code;
    
    public Target(int x, int y, int side, int xStep, int yStep)
    {
        this.x = x;
        this.y = y;
        this.side = side;
        this.xStep = xStep;
        this.yStep = yStep;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getSide() {
        return side;
    }

    public Color getColor() {
        return color;
    }

    public String getCode() {
        return code;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public void setCode(String code) {
        this.code = code;
    }
    
    public boolean isHit(Point posHit)
    {
        if(posHit.x > x && posHit.x < x+side)
        {
            if(posHit.y > y && posHit.y < y+side)
            {
                return true;
            }
        }
        return false;
    }
    
    public void move(int width, int height)
    {
        x = x + xStep;
        y = y + yStep;
        if(x+side >= width)
        {
            xStep = -xStep;
            x = width - side-1;
        }
        if(x < 0)
        {
            xStep = -xStep;
            x = 0;
        }
        if(y+side >= height)
        {
            yStep = -yStep;
            y = height - side-1;
        }
        if(y < 0)
        {
            yStep = -yStep;
            y = 1;
        }
    }
    
    public void increaseSpeed(double percent)
    {
        xStep = xStep + (int)(xStep*percent);
        yStep = yStep + (int)(yStep*percent);
    }
    
    public void draw(Graphics g)
    {
        g.setColor(Color.BLACK);
        g.drawRect(x, y, side, side);
    }
    
}
