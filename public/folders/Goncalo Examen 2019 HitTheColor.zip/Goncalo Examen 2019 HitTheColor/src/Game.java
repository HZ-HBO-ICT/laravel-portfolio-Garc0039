
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author estgo
 */
public class Game 
{
    
    private ArrayList<Target> alTargets = new ArrayList<Target>();
    
    public int getDifficulty()
    {
        if(alTargets.size() <= 1)
        {
            return 0;
        }
        else
        {
            return alTargets.size() -1;
        }
    }
    
    
    public int calculateRandomNumber(int min, int max)
    {
        return (int)(Math.random()*(max-min+1))+min;
    }
    
    public void sort()
    {
        Target atPos;
        for(int i = 0; i < alTargets.size() -1; i++)
        {
            atPos = alTargets.get(i);
            for(int j = 0; j < alTargets.size(); j++)
            {
                if(alTargets.get(j).getCode().compareTo(atPos.getCode()) < 0)
                {
                    alTargets.set(i, alTargets.get(j));
                    alTargets.set(j, atPos);
                    atPos = alTargets.get(j);
                }
            }
        }
    }
    
    public int find(String code)
    {
        int number = -1; 
        int i = 0;
        while(i < alTargets.size() && number == -1)
        {
            if(alTargets.get(i).getCode().equals(code))
            {
                number = i;
            }
            i++;
        }
        
        return number;
        
    }
    
    public void createColorAndCode(Target t)
    {
        int R, G, B, min, max;
        min = 0;
        max = 255;
        String code = "";
        do
        {
            R = calculateRandomNumber(min, max);
            G = calculateRandomNumber(min, max);
            B = calculateRandomNumber(min, max);
            code = R + "-" + G + "-" + B;
        }
        while(find(code) != -1);
                
        t.setCode(code);
        Color color = new Color(R,G,B);
        t.setColor(color);
        
        
    }
    
    public void addRandomTarget(int width, int height)
    {
        int side, x , y, xStep, yStep;
        side = calculateRandomNumber(30, 60);
        x = calculateRandomNumber(0, width - side);
        y = calculateRandomNumber(0, height-side);
        xStep = calculateRandomNumber(-25, 25);
        yStep = calculateRandomNumber(-25, 25);
        int kind = calculateRandomNumber(0, 1);
        Target randomTarget;
        if(kind == 0)
        {
            randomTarget = new Circle(x, y, side, xStep, yStep);
        }
        else
        {
            randomTarget = new Square(x, y, side, xStep, yStep);
        }
        
        
        createColorAndCode(randomTarget);
        alTargets.add(randomTarget);
        //sort();
        
        
    }
    
    public Target selectRandomTarget()
    {
        int min, max;
        min = 0;
        max = alTargets.size()-1;
        if(alTargets.size() < 1)
        {
            return null;
        }
        
        int randomTarget = calculateRandomNumber(min, max);
        return alTargets.get(randomTarget);
    }
    
    public void move(int width, int height)
    {
        for(int i = 0; i<alTargets.size(); i++)
        {
            alTargets.get(i).move(width, height);
        }
    }
    
    public void increaseSpeed(double percent)
    {
        for(int i = 0; i<alTargets.size(); i++)
        {
            alTargets.get(i).increaseSpeed(percent);
        }
    }
    
    public void draw(Graphics g)
    {
     
        for(int i = 0; i<alTargets.size(); i++)
        {
            alTargets.get(i).draw(g);
        }
     
    }
    
}
