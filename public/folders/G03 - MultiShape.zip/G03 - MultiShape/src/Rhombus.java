
import java.awt.Color;
import java.awt.Graphics;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GarDa256
 */
public class Rhombus extends Line
{
    
    public Rhombus(int x, int y, int with, int height, Color color)
    {
        super(x, y, with, height, color);
    }
    
    public void draw(Graphics g)
    {
        super.draw(g);
        
        g.drawLine(getX(), getY(), getX()-getWidth(), getY()+getHeight());
        g.drawLine(getX()-getWidth(), getY()+getHeight(), getX(), getY()+getHeight()*2);
        g.drawLine(getX()+getWidth(), getY()+getHeight(), getX(), getY()+getHeight()*2);
        
        g.drawLine(getX(), getY(), getX(), getY()+getHeight()*2);
        g.drawLine(getX()-getWidth(), getY()+getHeight(), getX()+getWidth(), getY()+getHeight());
    }
}
