
import java.awt.Color;
import java.awt.Graphics;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GARDA256
 */
public class Rectangle extends Shape
{
    private Color borderColor;
    
    public Rectangle(int x, int y, int with, int height, Color color, Color borderColor)
    {
        super(x, y, with, height, color); 
        this.borderColor = borderColor; 
    }

    public Color getBorderColor()
    {
        return borderColor;
    }
    
    public int calcLeftX()
    {
        // DrawRect et FillRect ont besoin du x le plus grand a gauche
        // donc le minimum des 2 x cad
        // x1 = getX()
        // x2 = x1+getWidth
        
        int x1, x2, x;
        
        x1=getX();
        x2= x1+getWidth();
        x=Math.min(x1, x2);
        
        return x;
    }
    
    public int calcTopY()
    {
        // voir commentaires de calcLeftX
        
        int y1, y2, y;
        y1 = getY();
        y2 = y1+getHeight();
        
        y = Math.min(y1, y2);
        return y;
    }
    
    public void draw(Graphics g)
    {         
        g.setColor(getColor());
        g.fillRect(calcLeftX(), calcTopY(), Math.abs(getWidth()), Math.abs(getHeight()));
        System.out.println("Width= "+getWidth()+" Height="+getHeight());
        g.setColor(borderColor);
        g.drawRect(calcLeftX(), calcTopY(), Math.abs(getWidth()), Math.abs(getHeight()));
    }
    
}
