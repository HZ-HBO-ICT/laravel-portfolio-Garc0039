
import java.awt.Color;
import java.awt.Graphics;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GARDA256
 */
public class Shape
{
    private int x;
    private int y;
    private int width;
    private int height;
    private Color color;

    public Shape(int x, int y, int with, int height, Color color)
    {
        this.x = x;
        this.y = y;
        this.width = with;
        this.height = height;
        this.color = color;
    }

    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }

    public int getWidth()
    {
        return width;
    }

    public int getHeight()
    {
        return height;
    }

    public Color getColor()
    {
        return color;
    }

    public void setWidth(int width)
    {
        this.width = width;
    }

    public void setHeight(int height)
    {
        this.height = height;
    }
    
    public void draw(Graphics g)
    {
        // Peter draw will never be called 
    }
}
