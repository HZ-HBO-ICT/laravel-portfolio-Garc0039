
import java.awt.Color;
import java.awt.Graphics;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GARDA256
 */
public class Ellipse extends Rectangle
{
    
    public Ellipse(int x, int y, int with, int height, Color color, Color borderColor)
    {
        super(x, y, with, height, color, borderColor);
    }
    
    public void draw(Graphics g)
    {   
        g.setColor(getColor());
        g.fillOval(calcLeftX(), calcTopY(), Math.abs(getWidth()), Math.abs(getHeight()));
        g.setColor(getBorderColor());
        g.drawOval(calcLeftX(), calcTopY(), Math.abs(getWidth()), Math.abs(getHeight()));
    }
}
