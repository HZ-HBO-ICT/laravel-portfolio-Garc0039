
import java.awt.Color;
import java.awt.Graphics;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GarDa256
 */
public class Triangle extends Line
{

    public Triangle(int x, int y, int with, int height, Color color)
    {
        super(x, y, with, height, color);
    }
    
    public void draw(Graphics g)
    {
        int x1, x2, y1, y2, x3, y3;
        super.draw(g); // Dessiner hypothenuse 
        x1=getX();
        y1=getY();
        x2=x1;
        y2=y1+getHeight();
        x3=x1+getWidth();
        y3=y1+getHeight();
        
        g.drawLine(x1, y1, x2, y2);
        g.drawLine(x2, y2, x3, y3);
    }
}
